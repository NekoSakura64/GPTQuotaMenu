// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "GPTQuotaMenu",
    platforms: [.macOS(.v13)],
    targets: [.executableTarget(name: "GPTQuotaMenu")]
)
