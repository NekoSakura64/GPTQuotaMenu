import AppKit
import Foundation

struct RateWindow {
    let usedPercent: Int
    let resetAt: Date
    var remainingPercent: Int { max(0, min(100, 100 - usedPercent)) }
}

final class CodexUsageClient {
    private var task: Process?
    private var input: FileHandle?
    private var buffer = Data()
    private var initialized = false
    var onUsage: ((RateWindow, RateWindow) -> Void)?
    var onError: ((String) -> Void)?

    func refresh() {
        stop()
        initialized = false
        let executable = FileManager.default.fileExists(atPath: "/Applications/ChatGPT.app/Contents/Resources/codex")
            ? "/Applications/ChatGPT.app/Contents/Resources/codex" : "/usr/local/bin/codex"
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = ["app-server", "--stdio"]
        let stdin = Pipe(), stdout = Pipe(), stderr = Pipe()
        process.standardInput = stdin
        process.standardOutput = stdout
        process.standardError = stderr
        stdout.fileHandleForReading.readabilityHandler = { [weak self] handle in
            self?.receive(handle.availableData)
        }
        // Codex may print harmless startup warnings to stderr; the JSON response is authoritative.
        stderr.fileHandleForReading.readabilityHandler = { _ in }
        process.terminationHandler = { [weak self] _ in
            if self?.initialized == false { self?.onError?("无法连接本机 Codex。请先在 ChatGPT Desktop 登录。") }
        }
        do {
            try process.run()
            task = process
            input = stdin.fileHandleForWriting
            send(id: 1, method: "initialize", params: [
                "clientInfo": ["name": "gpt-quota-menu", "version": "1.0.0"]
            ])
        } catch {
            onError?("启动 Codex 失败：\(error.localizedDescription)")
        }
    }

    private func receive(_ data: Data) {
        buffer.append(data)
        while let newline = buffer.firstIndex(of: 10) {
            let line = buffer.prefix(upTo: newline)
            buffer.removeSubrange(...newline)
            guard let object = try? JSONSerialization.jsonObject(with: line) as? [String: Any] else { continue }
            if (object["id"] as? Int) == 1 {
                initialized = true
                send(id: 2, method: "account/rateLimits/read", params: ["excludeResetCreditDetails": true])
            } else if (object["id"] as? Int) == 2 {
                parseUsage(object["result"] as? [String: Any])
            }
        }
    }

    private func parseUsage(_ result: [String: Any]?) {
        guard let limits = result?["rateLimits"] as? [String: Any],
              let primary = window(limits["primary"]), let secondary = window(limits["secondary"]) else {
            onError?("未读取到额度信息。请确认已登录 ChatGPT Desktop。")
            return
        }
        DispatchQueue.main.async { self.onUsage?(primary, secondary) }
    }

    private func window(_ value: Any?) -> RateWindow? {
        guard let dict = value as? [String: Any], let used = dict["usedPercent"] as? Int,
              let reset = dict["resetsAt"] as? TimeInterval else { return nil }
        return RateWindow(usedPercent: used, resetAt: Date(timeIntervalSince1970: reset))
    }

    private func send(id: Int, method: String, params: [String: Any]) {
        guard let input, let data = try? JSONSerialization.data(withJSONObject: ["id": id, "method": method, "params": params]) else { return }
        input.write(data + Data([10]))
    }

    private func stop() {
        task?.terminationHandler = nil
        task?.terminate()
        task = nil
        input = nil
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private let statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    private let client = CodexUsageClient()
    private let detailItem = NSMenuItem(title: "正在读取额度…", action: nil, keyEquivalent: "")
    private var timer: Timer?
    private var activityToken: NSObjectProtocol?
    private var keepAliveWindow: NSWindow?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSLog("GPTQuotaMenu: launching")
        createInvisibleKeepAliveWindow()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
            ProcessInfo.processInfo.disableAutomaticTermination("GPT 余量需要常驻菜单栏")
            activityToken = ProcessInfo.processInfo.beginActivity(
                options: [.automaticTerminationDisabled, .suddenTerminationDisabled],
                reason: "持续显示 GPT 余量"
            )
            NSLog("GPTQuotaMenu: automatic termination disabled after restoration")
        }
        let menu = NSMenu()
        menu.addItem(detailItem)
        menu.addItem(NSMenuItem.separator())
        menu.addItem(withTitle: "立即刷新", action: #selector(refresh), keyEquivalent: "r").target = self
        menu.addItem(withTitle: "退出", action: #selector(quit), keyEquivalent: "q").target = self
        statusItem.menu = menu
        statusItem.button?.title = "GPT--"
        NSLog("GPTQuotaMenu: status item created")
        client.onUsage = { [weak self] short, weekly in self?.show(short: short, weekly: weekly) }
        client.onError = { [weak self] message in DispatchQueue.main.async { self?.showError(message) } }
        refresh()
        timer = Timer.scheduledTimer(timeInterval: 60, target: self, selector: #selector(refresh), userInfo: nil, repeats: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false
    }

    private func createInvisibleKeepAliveWindow() {
        let window = NSWindow(
            contentRect: NSRect(x: -10_000, y: -10_000, width: 1, height: 1),
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        window.isReleasedWhenClosed = false
        window.isOpaque = false
        window.backgroundColor = .clear
        window.alphaValue = 0.01
        window.hasShadow = false
        window.ignoresMouseEvents = true
        window.collectionBehavior = [.canJoinAllSpaces, .stationary]
        window.orderFrontRegardless()
        keepAliveWindow = window
    }

    @objc private func refresh() { client.refresh() }
    @objc private func quit() { NSApp.terminate(nil) }

    private func show(short: RateWindow, weekly: RateWindow) {
        statusItem.button?.title = "GPT\(short.remainingPercent)%"
        detailItem.title = "5 小时：剩 \(short.remainingPercent)%（\(resetText(short.resetAt)) 重置）\n每周：剩 \(weekly.remainingPercent)%（\(resetText(weekly.resetAt)) 重置）"
        detailItem.isEnabled = true
    }

    private func showError(_ message: String) {
        statusItem.button?.title = "GPT!"
        detailItem.title = message
        detailItem.isEnabled = false
    }

    private func resetText(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter(); formatter.locale = Locale(identifier: "zh_CN")
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
