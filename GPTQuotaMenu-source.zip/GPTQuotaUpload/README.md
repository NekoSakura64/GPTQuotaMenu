# GPT 余量菜单栏

macOS 菜单栏小工具，显示当前 ChatGPT/Codex 的 **5 小时窗口剩余额度**；点开可查看每周额度和重置时间。它通过本机已登录的 Codex 读取数据，不需要 API Key，也不会保存账号密码。

## 运行

在此目录执行：

```bash
swift run
```

首次构建完成后，右上角会出现 `GPT · 99%`。程序每分钟自动刷新，也可点菜单中的“立即刷新”。请保持 ChatGPT Desktop 已登录。

## 制作成应用

可以在 Xcode 中打开 `Package.swift`，选择 Product → Archive 后导出为 `.app`；将它拖进“登录项”即可开机启动。

## 说明

此工具显示 Codex/Work 共享额度，而不是普通 Chat 对话次数。具体可用额度仍以 ChatGPT Desktop 的“设置 → Usage/用量”为准。
